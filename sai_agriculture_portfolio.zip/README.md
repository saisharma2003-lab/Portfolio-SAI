# Agriculture Portfolio Website

## Preview
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a public repository, e.g. `sai-agriculture-portfolio`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After GitHub publishes it, your site URL will look like:
   `https://YOUR-USERNAME.github.io/sai-agriculture-portfolio/`
6. Add that URL to LinkedIn under **Contact info → Website** and/or **Featured → Add a link**.

## Before publishing
- Review the Syngenta Foundation India internship description and replace the placeholder with your actual responsibilities.
- Add completed projects only; the Projects section is intentionally left as a prompt rather than inventing work.
- Confirm all dates, certificate names and language proficiency levels.
- The phone number from the CV is not displayed publicly. Email and LinkedIn are included.
